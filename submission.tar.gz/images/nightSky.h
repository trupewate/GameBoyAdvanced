/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 nightSky nightSky.jpg 
 * Time-stamp: Wednesday 04/07/2021, 21:06:25
 * 
 * Image Information
 * -----------------
 * nightSky.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef NIGHTSKY_H
#define NIGHTSKY_H

extern const unsigned short nightSky[38400];
#define NIGHTSKY_SIZE 76800
#define NIGHTSKY_LENGTH 38400
#define NIGHTSKY_WIDTH 240
#define NIGHTSKY_HEIGHT 160

#endif


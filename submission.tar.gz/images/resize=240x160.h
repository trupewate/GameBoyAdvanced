/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 resize=240x160 lose.jpg 
 * Time-stamp: Friday 04/09/2021, 04:19:03
 * 
 * Image Information
 * -----------------
 * lose.jpg 800@685
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RESIZE240X160_H
#define RESIZE240X160_H

extern const unsigned short lose[548000];
#define LOSE_SIZE 1096000
#define LOSE_LENGTH 548000
#define LOSE_WIDTH 800
#define LOSE_HEIGHT 685

#endif


/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x30 player player.png 
 * Time-stamp: Friday 04/09/2021, 05:56:50
 * 
 * Image Information
 * -----------------
 * player.png 15@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYER_H
#define PLAYER_H

extern const unsigned short player[450];
#define PLAYER_SIZE 900
#define PLAYER_LENGTH 450
#define PLAYER_WIDTH 15
#define PLAYER_HEIGHT 30

#endif

